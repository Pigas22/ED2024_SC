package duplamente;

import dados.Item;

public class TestarCalculaMedia {

	public static void main(String[] args) {
		ListaDupla lista = new ListaDupla();
		double media;
		
		
		media = lista.calcularMedia();
		

			System.out.println("A média da lista é: " + media);

	}
}
